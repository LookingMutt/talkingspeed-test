// IShowSpeed Catchphrases and Responses
const catchphrases = [
    "YESSIR! 🔥",
    "Let's get it!",
    "SPEED GANG!",
    "We eatin' good tonight!",
    "BRRRR! 🥶",
    "No cap, no cap!",
    "We went crazy!",
    "I'm speeding! 💨",
    "That's tuff! 💯",
    "Go crazy!",
    "Aahhh! 🔥",
    "We out here!",
    "Let's run it!",
    "SPEED SPEED SPEED!",
    "Yessir, yessir, yessir!",
    "Man down! 💪"
];

const actionResponses = {
    feed: [
        "That hit different! 😋",
        "Bro I needed that! 🍗",
        "Food good, yessir!",
        "We eatin' good! 🔥"
    ],
    tickle: [
        "AHHHH! 😂",
        "Nah nah nah! 😂",
        "Stop it! 😄",
        "That's crazy! 🤣"
    ],
    hype: [
        "LET'S GOOOOO! 🔥🔥🔥",
        "YEAH YEAH YEAH!",
        "I'M HYPED NOW! 💯",
        "WORLD STAR! 🌟"
    ]
};

class TalkingIShowSpeed {
    constructor() {
        this.clicks = 0;
        this.energy = 100;
        this.maxEnergy = 100;
        this.isAnimating = false;
        
        this.character = document.getElementById('character');
        this.speechBubble = document.getElementById('speechBubble');
        this.speechText = document.getElementById('speechText');
        this.clickCountDisplay = document.getElementById('clickCount');
        this.energyBar = document.getElementById('energyBar');
        
        this.init();
    }

    init() {
        // Character click
        this.character.addEventListener('click', () => this.handleClick());
        
        // Button events
        document.getElementById('feedBtn').addEventListener('click', () => this.feed());
        document.getElementById('tickleBtn').addEventListener('click', () => this.tickle());
        document.getElementById('hypeBtn').addEventListener('click', () => this.getHyped());
        document.getElementById('resetBtn').addEventListener('click', () => this.reset());
        
        // Energy regeneration
        setInterval(() => this.regenEnergy(), 2000);
        
        this.updateUI();
    }

    handleClick() {
        if (this.isAnimating) return;
        if (this.energy < 10) {
            this.speak("I'm tired! 😴");
            return;
        }

        this.clicks++;
        this.energy = Math.max(0, this.energy - 10);
        
        this.animate('clicked');
        this.speak(this.getRandomPhrase(catchphrases));
        this.updateUI();
    }

    feed() {
        if (this.energy < 5) {
            this.speak("Too tired to eat... 😴");
            return;
        }

        this.energy = Math.min(this.maxEnergy, this.energy + 30);
        this.animate('dance');
        this.speak(this.getRandomPhrase(actionResponses.feed));
        this.updateUI();
    }

    tickle() {
        if (this.energy < 15) {
            this.speak("Can't tickle me, I'm tired! 😑");
            return;
        }

        this.energy = Math.max(0, this.energy - 15);
        this.animate('waving');
        this.speak(this.getRandomPhrase(actionResponses.tickle));
        this.updateUI();
    }

    getHyped() {
        if (this.energy < 20) {
            this.speak("I need energy first! 😓");
            return;
        }

        this.energy = Math.max(0, this.energy - 20);
        this.character.classList.remove('dance');
        void this.character.offsetWidth; // Trigger reflow
        this.character.classList.add('dance');
        
        this.speak(this.getRandomPhrase(actionResponses.hype));
        
        setTimeout(() => {
            this.character.classList.remove('dance');
        }, 2000);
        
        this.updateUI();
    }

    speak(text) {
        this.speechText.textContent = text;
        this.speechBubble.classList.remove('show');
        
        // Trigger reflow to restart animation
        void this.speechBubble.offsetWidth;
        this.speechBubble.classList.add('show');
        
        // Remove after delay
        setTimeout(() => {
            this.speechBubble.classList.remove('show');
        }, 3000);
    }

    animate(animationType) {
        if (this.isAnimating) return;
        this.isAnimating = true;

        this.character.classList.add(animationType);

        setTimeout(() => {
            this.character.classList.remove(animationType);
            this.isAnimating = false;
        }, animationType === 'clicked' ? 500 : 600);
    }

    regenEnergy() {
        if (this.energy < this.maxEnergy) {
            this.energy = Math.min(this.maxEnergy, this.energy + 5);
            this.updateUI();
        }
    }

    updateUI() {
        this.clickCountDisplay.textContent = this.clicks;
        const energyPercent = (this.energy / this.maxEnergy) * 100;
        this.energyBar.style.width = energyPercent + '%';
    }

    getRandomPhrase(arr) {
        return arr[Math.floor(Math.random() * arr.length)];
    }

    reset() {
        this.clicks = 0;
        this.energy = this.maxEnergy;
        this.speechBubble.classList.remove('show');
        this.updateUI();
        this.speak("Let's start fresh! 🔥");
    }
}

// Start the game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TalkingIShowSpeed();
});
